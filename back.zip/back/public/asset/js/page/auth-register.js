"use strict";

$(".pwstrength").pwstrength();